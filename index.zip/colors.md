#96BAA0 Meadow Mist
#014038 Canopy Green
#BDD4DA Sky Bloom
#F0C06D Sunlit Petal
#F7F7F7 Cloudy Grey
#00231C Detritus Green